package com.weixin.test;

import java.util.List;

import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.weixin.bean.Student;
import com.weixin.service.StudentService;

public class StudentTest {
	
	
	@Test
	public void test1() {
		ClassPathXmlApplicationContext classPathXmlApplicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
		StudentService studentService = classPathXmlApplicationContext.getBean(StudentService.class);
		List<Student> selectAll = studentService.selectAll();
		System.out.println(selectAll);
	}
}
