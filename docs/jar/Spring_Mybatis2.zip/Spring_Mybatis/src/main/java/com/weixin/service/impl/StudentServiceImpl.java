package com.weixin.service.impl;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.weixin.bean.Student;
import com.weixin.mapper.StudentMapper;
import com.weixin.service.StudentService;

@Service
public class StudentServiceImpl implements StudentService{
	
//	@Autowired
//	private SqlSessionTemplate sqlSessionTemplate;
	@Autowired
	private StudentMapper studentMapper;
	
	@Override
	public List<Student> selectAll() {
		List<Student> studentList = studentMapper.selectAll();
		return studentList;
	}

}
