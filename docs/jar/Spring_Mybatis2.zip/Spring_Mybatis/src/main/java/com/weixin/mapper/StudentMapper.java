package com.weixin.mapper;

import java.util.List;

import com.weixin.bean.Student;


public interface StudentMapper {
	List<Student> selectAll();
}
