package com.weixin.service;

import java.util.List;

import com.weixin.bean.Student;

public interface StudentService {
	List<Student> selectAll();
}
