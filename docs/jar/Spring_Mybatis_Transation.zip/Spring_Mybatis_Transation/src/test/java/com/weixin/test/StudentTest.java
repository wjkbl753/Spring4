package com.weixin.test;

import java.util.List;

import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.weixin.bean.Student;
import com.weixin.service.StudentService;

public class StudentTest {
	
	
	@Test
	public void test1() {
		ClassPathXmlApplicationContext classPathXmlApplicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
		StudentService studentService = classPathXmlApplicationContext.getBean(StudentService.class);
		List<Student> selectAll = studentService.selectAll();
		System.out.println(selectAll);
	}
	
	@Test
	public void test2() {
		ClassPathXmlApplicationContext classPathXmlApplicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
		StudentService studentService = classPathXmlApplicationContext.getBean(StudentService.class);
		boolean b = studentService.add();
		System.out.println(b);
	}
	
	@Test
	public void test3() {
		ClassPathXmlApplicationContext classPathXmlApplicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
		StudentService studentService = classPathXmlApplicationContext.getBean(StudentService.class);
		boolean b = studentService.addPlus();
		System.out.println(b);
	}
}
